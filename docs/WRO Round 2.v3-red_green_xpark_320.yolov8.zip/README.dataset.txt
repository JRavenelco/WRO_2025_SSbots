# WRO Round 2 > Red_Green_Xpark_320
https://universe.roboflow.com/traffic-sign-3jedo/wro-round-2

Provided by a Roboflow user
License: CC BY 4.0

